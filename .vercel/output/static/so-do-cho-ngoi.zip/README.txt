Giai nen, mo VS Code, chay: npm install && npm run dev
